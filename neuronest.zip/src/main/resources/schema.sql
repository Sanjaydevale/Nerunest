CREATE DATABASE IF NOT EXISTS neuronest_db;
USE neuronest_db;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    credits INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS daily_log (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    date DATE NOT NULL,
    study_hours INT NOT NULL,
    sleep_hours INT NOT NULL,
    distraction_hours INT NOT NULL,
    mood VARCHAR(50),
    productivity_score DOUBLE,
    user_id BIGINT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

INSERT INTO users (name, email, password, credits) VALUES
('Demo User', 'demo@neuronest.ai', 'password123', 0);
