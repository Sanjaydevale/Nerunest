package com.neuronest.controller;

import com.neuronest.dto.DailyLogRequest;
import com.neuronest.dto.DailyLogResponse;
import com.neuronest.service.DailyLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/logs")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class DailyLogController {

    private final DailyLogService dailyLogService;

    @PostMapping
    public ResponseEntity<DailyLogResponse> createLog(@RequestBody DailyLogRequest request) {
        DailyLogResponse response = dailyLogService.createLog(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{userId}")
    public ResponseEntity<List<DailyLogResponse>> getLogsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(dailyLogService.getLogsByUser(userId));
    }
}
