package com.neuronest.dto;

import lombok.*;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DailyLogResponse {
    private Long id;
    private LocalDate date;
    private int studyHours;
    private int sleepHours;
    private int distractionHours;
    private String mood;
    private double productivityScore;
    private String burnoutStatus;
    private String suggestion;
    private Long userId;
}
