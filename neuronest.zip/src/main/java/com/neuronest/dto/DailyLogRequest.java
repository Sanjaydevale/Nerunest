package com.neuronest.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DailyLogRequest {
    private Long userId;
    private int studyHours;
    private int sleepHours;
    private int distractionHours;
    private String mood;
}
